﻿using DotNetCoreWebApiProject.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;

namespace DotNetCoreWebApiProject.Extensions
{
    /// <summary>
    /// ServiceExtensions.
    /// </summary>
    public static class ServiceExtensions
    {
       
        /// <summary>
        /// Business services configuration.
        /// </summary>
        /// <param name="services">services.</param>
        /// <param name="configuration">configuration.</param>
        public static void ConfigureServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddMemoryCache();

            // Configure application services
            services.AddTransient<IECommerceService, ECommerceService>();
            services.AddTransient<ILibraryManagementService, LibraryManagementService>();

        }
    }
}
