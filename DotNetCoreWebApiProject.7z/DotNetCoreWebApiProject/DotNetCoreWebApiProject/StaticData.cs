﻿using DotNetCoreWebApiProject.Models;

namespace DotNetCoreWebApiProject
{
    public static class StaticData
    {
        public static List<Product> products  = new List<Product>();

    }
}
