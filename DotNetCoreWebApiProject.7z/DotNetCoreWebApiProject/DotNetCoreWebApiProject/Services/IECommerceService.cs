﻿using DotNetCoreWebApiProject.Models;

namespace DotNetCoreWebApiProject.Services
{
    public interface IECommerceService
    {
        List<Product> GetAllProducts();

        Product GetProductById(int productId);
        void AddNewProduct(Product product);

        void DeleteProduct(int productId);

        Product UpdateProduct(Product product);
    }
}
