﻿using DotNetCoreWebApiProject.Models;

namespace DotNetCoreWebApiProject.Services
{
    public class LibraryManagementService : ILibraryManagementService
    {

        public List<Product> GetAllProducts()
        {
            return StaticData.products;
        }

        public Product? GetProductById(int productId)
        {
            return StaticData.products.Where(x => x.id == productId).FirstOrDefault();
        }


        public void AddNewProduct(Product product)
        {
            StaticData.products.Add(product);
        }

        public void DeleteProduct(int productId)
        {
            var product = StaticData.products.Where(x => x.id == productId).FirstOrDefault();
            if (product != null)
            {
                StaticData.products.Remove(product);
            }
        }

        public Product UpdateProduct(Product product)
        {
            StaticData.products.ForEach(x =>
            {
                if (x.id == product.id)
                {
                    x.name = product.name;
                }
            });

            return StaticData.products.Where(x => x.id == product.id).FirstOrDefault()!;
        }
    }
}
