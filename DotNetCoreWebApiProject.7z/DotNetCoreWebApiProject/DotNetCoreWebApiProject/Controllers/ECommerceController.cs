using DotNetCoreWebApiProject.Models;
using DotNetCoreWebApiProject.Services;
using Microsoft.AspNetCore.Mvc;

namespace DotNetCoreWebApiProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ECommerceController : ControllerBase
    {
        private readonly ILogger<ECommerceController> _logger;
        private readonly IECommerceService ecommerceService;

        public ECommerceController(ILogger<ECommerceController> logger, IECommerceService service)
        {
            _logger = logger;
            ecommerceService = service;
        }

        [HttpGet]
        [Route("products")]
        public ActionResult<List<Product>> Get()
        {
            return Ok(ecommerceService.GetAllProducts());
        }

        [HttpPost]
        [Route("product")]
        public ActionResult Post([FromBody] Product product)
        {
            ecommerceService.AddNewProduct(product);
            return Ok();
        }

        [HttpGet]
        [Route("product/{productId}")]
        public ActionResult<Product> GetProduct(int productId)
        {
            return Ok(ecommerceService.GetProductById(productId));
        }

        [HttpPut]
        [Route("product")]
        public ActionResult<Product> Put([FromBody] Product product)
        {
            return ecommerceService.UpdateProduct(product);
        }

        [HttpDelete]
        [Route("product/{productId}")]
        public ActionResult Delete(int productId)
        {
            ecommerceService.DeleteProduct(productId);
            return Ok();
        }
    }
}