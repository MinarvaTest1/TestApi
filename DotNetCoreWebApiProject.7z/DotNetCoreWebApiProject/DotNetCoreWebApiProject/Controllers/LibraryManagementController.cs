using DotNetCoreWebApiProject.Models;
using DotNetCoreWebApiProject.Services;
using Microsoft.AspNetCore.Mvc;

namespace DotNetCoreWebApiProject.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class LibraryManagementController : ControllerBase
    {
        private readonly ILogger<LibraryManagementController> _logger;
        private readonly ILibraryManagementService libraryManagementService;

        public LibraryManagementController(ILogger<LibraryManagementController> logger, ILibraryManagementService service)
        {
            _logger = logger;
            libraryManagementService = service;
        }

        //[HttpGet]
        //[Route("products")]
        //public ActionResult<List<Product>> Get()
        //{
        //    return Ok(ecommerceService.GetAllProducts());
        //}

        //[HttpPost]
        //[Route("product")]
        //public ActionResult Post([FromBody] Product product)
        //{
        //    ecommerceService.AddNewProduct(product);
        //    return Ok();
        //}

        //[HttpGet]
        //[Route("product/{productId}")]
        //public Product GetProduct(int productId)
        //{
        //    return ecommerceService.GetProductById(productId);
        //}

        //[HttpPut]
        //[Route("product")]
        //public ActionResult<Product> Put([FromBody] Product product)
        //{
        //    return ecommerceService.UpdateProduct(product);
        //}

        //[HttpDelete]
        //[Route("product/{productId}")]
        //public ActionResult Delete(int productId)
        //{
        //    ecommerceService.DeleteProduct(productId);
        //    return Ok();
        //}
    }
}