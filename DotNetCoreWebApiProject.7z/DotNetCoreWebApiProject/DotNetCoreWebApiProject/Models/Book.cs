﻿using System.ComponentModel.DataAnnotations;

namespace DotNetCoreWebApiProject.Models
{
    public enum BookType
    {
        fiction,
        nonFiction,
        science,
        technology,
        art
    }

    public class Book
    {
        [Required]
        public int id { get; set; }

        [Required]
        public string Title { get; set; }

        [Required]
        public string Author { get; set; }

        [Required]
        public bool IsAvailable { get; set; }

        [Required]
        public BookType BookType { get; set; }
    }
}
