using DotNetCoreWebApiProject.Controllers;
using DotNetCoreWebApiProject.Models;
using DotNetCoreWebApiProject.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;

namespace TestProject1
{
    public class Tests
    {
        private Mock<ILogger<ECommerceController>> mockLogger;
        private Mock<IECommerceService> mockService;
        private ECommerceController controller;

        [SetUp]
        public void Setup()
        {
            mockLogger = new Mock<ILogger<ECommerceController>>();
            mockService = new Mock<IECommerceService>();

            controller = new ECommerceController(mockLogger.Object, mockService.Object);
        }

        [Test]
        public void TestAllProductsSuccess()
        {
            var res = new List<Product> { new Product { id = 1, name = "P1" } };
            mockService.Setup(service => service.GetAllProducts())
                           .Returns(res);
            var apiRes = controller.Get();
            Assert.NotNull(apiRes.Result);
            var result = (OkObjectResult)apiRes.Result;
            Assert.AreEqual(res.Count, ((List<Product>)result?.Value)?.Count);
        }

        [Test]
        public void TestAddNewProductSuccess()
        {
            var data = new Product { id = 1, name = "P1" };
            mockService.Setup(service => service.AddNewProduct(It.IsAny<Product>()));
            var apiRes = controller.Post(data);
            Assert.NotNull(apiRes);
        }

        [Test]
        public void TestGetProductSuccess()
        {
            var res = new Product { id = 1, name = "P1" };
            mockService.Setup(service => service.GetProductById(It.IsAny<int>()))
                           .Returns(res);
            var apiRes = controller.GetProduct(1);
            Assert.NotNull(apiRes);
            var result = (OkObjectResult)apiRes.Result;
            Assert.AreEqual(res.id, ((Product)result?.Value).id);
        }

        [Test]
        public void TestUpdateProductSuccess()
        {
            var data = new Product { id = 1, name = "P1" };
            mockService.Setup(service => service.UpdateProduct(It.IsAny<Product>()));
            var apiRes = controller.Put(data);
            Assert.NotNull(apiRes);
        }

        [Test]
        public void TestDeleteProductSuccess()
        {
            mockService.Setup(service => service.DeleteProduct(It.IsAny<int>()));
            var apiRes = controller.Delete(1);
            Assert.NotNull(apiRes);
        }
    }
}